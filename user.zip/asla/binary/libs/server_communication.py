class ServerCommunication(object):
    """ class for handling server communication"""
    def __init__(self):
        self.profile = Profile()
        self.atoken = 0
        self.model = Model()
    def verifyAuthTokenFromServer(atoken):
        """verifies if the aauthentication token expert enetered is valid"""

    def fetchProfileFromServer():
        """ fetch user profile from server"""

    def updateModel():
        """ updates model for the user if its stale"""

    def loadGlobalModel():
        """ loads Global Model into memory. for faster calcualtion"""

    def getGlobalModelFromServer():
        """ gets global classfier model from the server and pickles it on user machine"""

    
